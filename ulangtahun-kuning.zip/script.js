function checkCode() {
  const input = document.getElementById('codeInput').value.trim().toLowerCase();
  const error = document.getElementById('error');
  if (input === 'kam') {
    document.getElementById('step1').classList.add('hidden');
    document.getElementById('step2').classList.remove('hidden');
  } else {
    error.classList.remove('hidden');
  }
}

function showSurprise() {
  document.getElementById('surprise').classList.remove('hidden');
}
